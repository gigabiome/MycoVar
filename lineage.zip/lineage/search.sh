while read -r line; do
    grep "$line" tmp.txt
done < input/YA00585723.snp
